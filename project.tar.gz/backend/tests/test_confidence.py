from app.services.territory_service import confidence


def test_confidence_high():
    assert confidence(90, 80) == "high"


def test_confidence_medium():
    assert confidence(60, 15) == "medium"


def test_confidence_low():
    assert confidence(10, 8) == "low"
