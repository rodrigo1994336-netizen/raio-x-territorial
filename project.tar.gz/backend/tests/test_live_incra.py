from app.live_sources.incra import IncraLiveClient, parse_first_feature_type_name

CAP = '''<?xml version="1.0" encoding="UTF-8"?>
<WFS_Capabilities xmlns:wfs="http://www.opengis.net/wfs">
  <wfs:FeatureTypeList>
    <wfs:FeatureType><wfs:Name>ms:certificada_sigef_particular_mg</wfs:Name></wfs:FeatureType>
  </wfs:FeatureTypeList>
</WFS_Capabilities>'''


class TextResult:
    text = CAP
    status_code = 200
    final_url = 'https://acervofundiario.incra.gov.br/fake-cap'
    sha256 = 'c' * 64


class JsonResult:
    status_code = 200
    final_url = 'https://acervofundiario.incra.gov.br/fake-feature'
    sha256 = 'd' * 64
    data = {
        'type':'FeatureCollection',
        'features':[{
            'id':'sigef.1',
            'properties':{
                'parcela_co':'ABC123', 'detentor_n':'DETENTOR TESTE',
                'registro_m':'18742', 'registro_c':'03.456-7', 'codigo_imo':'9500000000010',
                'area_hecta':147.1
            },
            'geometry':{'type':'Polygon','coordinates':[[[-44.4,-18.8],[-44.3,-18.8],[-44.3,-18.7],[-44.4,-18.8]]]}
        }]
    }


class FakeHttp:
    def __init__(self): self.calls=[]
    def get_text(self,url,*,params): self.calls.append(('text',url,params)); return TextResult()
    def get_json(self,url,*,params): self.calls.append(('json',url,params)); return JsonResult()


def test_parse_first_feature_type_name_namespace_safe():
    assert parse_first_feature_type_name(CAP) == 'ms:certificada_sigef_particular_mg'


def test_incra_sigef_discovers_then_fetches_bbox():
    http=FakeHttp()
    client=IncraLiveClient(http=http)
    fc=client.fetch_bbox('sigef','MG',(-44.5,-18.9,-44.2,-18.6))
    assert len(fc.features)==1
    assert fc.features[0].external_id=='sigef.1'
    assert fc.features[0].properties['registro_m']=='18742'
    assert http.calls[1][2]['typeName']=='ms:certificada_sigef_particular_mg'
    assert http.calls[1][2]['bbox']=='-44.5,-18.9,-44.2,-18.6'


def test_incra_snci_theme_url_is_distinct():
    url=IncraLiveClient.endpoint_for('snci','MG')
    assert 'imoveiscertificados_privado_mg' in url
