from app.live_sources.sicar import SicarWfsClient
from app.live_sources.probe import SourceProbeService
from app.live_sources.service import PropertyLiveSyncService

CAR = "MG-3120904-DFB380BECD7A4323AD8AA68FA14D011F"


class JsonResult:
    status_code=200
    final_url='https://example.test/query'
    sha256='f'*64
    data={
        'type':'FeatureCollection',
        'features':[{
            'id':'x.1',
            'properties':{'cod_imovel':CAR,'municipio':'CURVELO','num_area':14.795,'ind_status':'AT','ind_tipo':'IRU'},
            'geometry':{'type':'Polygon','coordinates':[[[-44.4,-18.8],[-44.39,-18.8],[-44.39,-18.79],[-44.4,-18.8]]]}
        }]
    }


class AlwaysFailHttp:
    def get_json(self,*args,**kwargs):
        raise RuntimeError('tls')


class WorkingHttp:
    def get_json(self,*args,**kwargs):
        return JsonResult()


def test_sicar_uses_controlled_tls_fallback():
    row=SicarWfsClient(http=AlwaysFailHttp(),fallback_http=WorkingHttp()).fetch_property(CAR)
    assert row.car_code==CAR
    assert 'TLS-FALLBACK' in row.raw['_typename']


class ProbeText:
    status_code=200; final_url='https://ok'; text='<xml/>'; sha256='a'*64
class ProbeJson:
    status_code=200; final_url='https://ok'; data={}; sha256='b'*64
class ProbeHttp:
    def get_text(self,*args,**kwargs): return ProbeText()
    def get_json(self,*args,**kwargs): return ProbeJson()


def test_source_probe_contract_returns_five_sources():
    p=SourceProbeService(); p.http=ProbeHttp(); p.insecure_http=ProbeHttp()
    rows=p.all()
    assert len(rows)==5
    assert all(r.ok for r in rows)
    assert {r.source for r in rows}=={'sicar','incra_sigef','ibama_embargos','inpe_prodes','anm'}


class JobRepo:
    def __init__(self): self.events=[]
    def update_job(self,job_id,**kwargs): self.events.append((job_id,kwargs))


class FakeSyncService(PropertyLiveSyncService):
    def sync(self,car_code,**kwargs):
        return {'car_code':car_code,'sources':{'sicar':{'status':'ok'},'anm':{'status':'empty'}}}


def test_job_marks_complete_when_all_sources_valid():
    repo=JobRepo(); svc=FakeSyncService.__new__(FakeSyncService); svc.repo=repo
    svc.run_job('j1',CAR)
    assert repo.events[0][1]['status']=='running'
    assert repo.events[-1][1]['status']=='complete'


class PartialSyncService(PropertyLiveSyncService):
    def sync(self,car_code,**kwargs):
        return {'car_code':car_code,'sources':{'sicar':{'status':'ok'},'incra':{'status':'unavailable'}}}


def test_job_marks_partial_when_source_unavailable():
    repo=JobRepo(); svc=PartialSyncService.__new__(PartialSyncService); svc.repo=repo
    svc.run_job('j1',CAR)
    assert repo.events[-1][1]['status']=='partial'


def test_canonical_date_rejects_ambiguous_and_accepts_known_formats():
    from app.live_sources.repository import _canonical_date
    assert _canonical_date('2026-09-04T10:11:12Z') == '2026-09-04'
    assert _canonical_date('04/09/2026') == '2026-09-04'
    assert _canonical_date('09/04/26') is None


def test_runtime_blueprint_wires_database_and_healthcheck():
    from pathlib import Path
    text=(Path(__file__).resolve().parents[2]/'render.yaml').read_text(encoding='utf-8')
    assert 'raio-x-territorial-db' in text
    assert 'fromDatabase:' in text
    assert 'property: connectionString' in text
    assert 'healthCheckPath: /health/ready' in text
