import json
from pathlib import Path

FIXTURE = Path(__file__).resolve().parents[1] / "fixtures" / "curvelo_reference_from_uploaded_report.json"


def test_reference_fixture_preserves_all_visible_competitor_sections():
    data = json.loads(FIXTURE.read_text(encoding="utf-8"))
    required = {
        "property", "car_areas", "fundiary", "compliance", "prodes", "aptitude",
        "water_grants", "iphan", "aerodromes", "warehouses", "soil", "precipitation"
    }
    assert required <= set(data)
    assert data["property"]["car_code"] == "MG-3120904-DFB380BECD7A4323AD8AA68FA14D011F"
    assert data["car_areas"]["app_to_restore_ha"] == 1.3961
    assert data["prodes"][0]["area_ha"] == 0.05
    assert len(data["aptitude"]) == 2
    assert len(data["iphan"]) == 2
    assert len(data["warehouses"]) == 2
    assert data["soil"]["clay_pct"] == 32.9
    assert data["precipitation"]["days_with_data"] == 29


def test_reference_is_explicitly_not_a_live_query():
    data = json.loads(FIXTURE.read_text(encoding="utf-8"))
    assert data["meta"]["not_live_query"] is True
