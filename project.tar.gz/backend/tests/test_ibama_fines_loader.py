from importlib.util import spec_from_file_location, module_from_spec
from pathlib import Path

P=Path(__file__).resolve().parents[2]/'scripts'/'sync_ibama_fines.py'
spec=spec_from_file_location('sync_ibama_fines',P); mod=module_from_spec(spec); spec.loader.exec_module(mod)


def test_header_aliases_and_privacy_scrub():
    row={'NUM_AUTO_INFRACAO':'123','SERIE':'A','NOME_AUTUADO':'Fulano','CPF_CNPJ':'000','LATITUDE':'-18,5','LONGITUDE':'-44,5'}
    assert mod.pick(row,'auto')=='123'
    assert mod.num(mod.pick(row,'lat'))==-18.5
    clean=mod.scrub_public(row)
    assert 'CPF_CNPJ' not in clean
    assert clean['NOME_AUTUADO']=='Fulano'
