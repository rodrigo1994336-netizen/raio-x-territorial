from datetime import datetime, timezone
from app.services.defense_service import estimate_deadline, EnvironmentalDefenseService


def test_ibama_base_deadlines_are_explicitly_estimates():
    dt=datetime(2026,9,1,12,tzinfo=timezone.utc)
    d,note=estimate_deadline('defense',dt)
    assert (d-dt).days==20
    assert 'Estimativa-base' in note
    a,_=estimate_deadline('final_arguments',dt)
    assert (a-dt).days==10
    r,_=estimate_deadline('appeal',dt)
    assert (r-dt).days==20


class FakeRepo:
    def get_auto(self, auto_id):
        return {'id':auto_id,'auto_numero':'12345','serie':'A','process_number':'02000.1','issued_at':'2026-08-01','description':'Descrição pública da autuação','fine_value':10000}
    def legal_basis(self, auto_id):
        return [{'norm':'Decreto 6.514/2008','article':'art. X','paragraph':None,'item':None,'description':'Enquadramento de teste'}]
    def save_draft(self, case_id,draft_type,content,source_snapshot):
        return {'case_id':case_id,'draft_type':draft_type,'content_markdown':content,'requires_human_review':True}


def test_draft_does_not_invent_facts_and_requires_review():
    s=EnvironmentalDefenseService(repo=FakeRepo())
    out=s.build_draft('c1','a1','appeal',{'Versão do interessado':'Não reconhece o local'},['Mapa georreferenciado'],'Revisão da autuação conforme provas')
    text=out['content_markdown']
    assert 'Não reconhece o local' in text
    assert 'Não alegar fatos' in text
    assert out['requires_human_review'] is True
