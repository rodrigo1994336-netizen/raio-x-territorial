from app.services.environmental_service import EnvironmentalService


class FakeRepo:
    def list_problem_areas(self, car_code):
        return [
          {'severity':'critical','overlap_ha':5,'overlap_car_pct':5,'layer':'IBAMA_EMBARGO'},
          {'severity':'attention','overlap_ha':10,'overlap_car_pct':10,'layer':'PRODES'},
        ]
    def problem_summary(self, car_code):
        return {'problem_area_ha':12,'problem_area_pct':12,'geojson':{'type':'MultiPolygon','coordinates':[]}}
    def list_fines(self, car_code, radius_m=0):
        return [{'inside_property':True,'auto_numero':'1'},{'inside_property':False,'auto_numero':'2'}]


def test_environmental_map_summary_does_not_double_count_union():
    out=EnvironmentalService(repo=FakeRepo()).map_problems('MG-X')
    assert out['summary']['problem_area_ha']==12
    assert out['summary']['critical_hits']==1
    assert out['summary']['total_hits']==2


def test_fine_counts_inside_and_nearby():
    out=EnvironmentalService(repo=FakeRepo()).fines_near_property('MG-X',5000)
    assert out['inside_count']==1 and out['nearby_count']==1
